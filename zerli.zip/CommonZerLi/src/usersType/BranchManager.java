package usersType;

public class BranchManager {
	String firstName, lastName, iDString;
}
