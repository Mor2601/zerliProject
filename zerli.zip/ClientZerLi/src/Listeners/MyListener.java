package Listeners;

import logic.Item;

public interface MyListener {
	public void onClickListener(Item item);
}
